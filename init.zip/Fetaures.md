add grafana for unsuccessfull logins 

npx gatekit-cli init will be creates this files:
.env User.js Role.js roles.json

Login trying limit 