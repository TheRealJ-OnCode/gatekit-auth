/auth/register POST ----- Done qaqa
/auth/login  POST  ----- Done qaqa