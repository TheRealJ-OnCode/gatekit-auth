[✅] npx gatekit-auth roles:seed
[✅] npx gatekit-auth roles:seed --config ./my-roles.json
[✅] npx gatekit-auth roles:seed --config ./my-roles.js
[✅] npx gatekit-auth roles:delete --name admin
[✅] npx gatekit-auth roles:clear 
[✅] /auth/register
[✅] /auth/login
[✅] registerRole()
[✅] assignRole()
[✅] deleteRole()
[✅] getUserRoles()
[✅] removeRole()



[❌] initGatekit() funksiyasi baslayan kimi redis e baglanmaga calisir. Cox gumanki  blacklist tokenden dolayidir
[❌] db errorlari direkt olaraq gatekirerror altinda cixmir normal error olaraq cixir .

